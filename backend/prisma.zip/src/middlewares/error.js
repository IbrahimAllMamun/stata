// src/middlewares/error.js
const errorHandler = (err, req, res, next) => {
  // The client hung up mid-upload (navigated away, closed the tab, lost signal).
  // There is no socket left to answer on, and it is not a fault worth a stack
  // trace, so note it and stop.
  if (err.message === 'Request aborted' || err.code === 'ECONNABORTED' || req.destroyed) {
    console.warn(`[abort] client disconnected during ${req.method} ${req.originalUrl}`);
    return;
  }

  console.error(err.stack);

  // Once headers are out, Express must handle the failure itself.
  if (res.headersSent) return next(err);

  // Multer errors
  if (err.code === 'LIMIT_FILE_SIZE') {
    const maxMB = Math.round((parseInt(process.env.MAX_FILE_SIZE) || 15 * 1024 * 1024) / (1024 * 1024));
    return res.status(400).json({ success: false, message: `File too large. Max ${maxMB}MB allowed.` });
  }

  if (err.message && err.message.includes('Invalid file type')) {
    return res.status(400).json({ success: false, message: err.message });
  }

  // Prisma errors
  if (err.code === 'P2002') {
    const field = err.meta?.target?.[0] || 'field';
    return res.status(409).json({ success: false, message: `${field} already exists` });
  }

  if (err.code === 'P2025') {
    return res.status(404).json({ success: false, message: 'Record not found' });
  }

  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal server error';

  res.status(status).json({ success: false, message });
};

const notFound = (req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
};

module.exports = { errorHandler, notFound };